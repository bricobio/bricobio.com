sigma.plugins.dragNodes
=====================

Plugin developed by [José M. Camacho](https://github.com/josemazo).

---

This plugin provides a method to drag & drop nodes. At the moment, this plugin is not compatible with the WebGL renderer. Check the sigma.plugins.dragNodes function doc or the examples/drag-nodes.html code sample to know more.
