sigma.plugins.animate
=====================

Plugin developed by [Alexis Jacomy](https://github.com/jacomyal).

---

This plugin provides a method to animate a sigma instance by interpolating some node properties. Check the `sigma.plugins.animate` function doc or the `examples/animate.html` code sample to know more.
